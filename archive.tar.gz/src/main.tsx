import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { App } from '@/App';
import '@/styles/tokens.css';
import '@/styles/globals.css';

const container = document.getElementById('root');

if (!container) {
  throw new Error('Arise: #root is missing from index.html.');
}

createRoot(container).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
